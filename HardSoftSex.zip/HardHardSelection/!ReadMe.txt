!ReadMe

Main function: RunSimulations.m
Set the parameter values in this file in the parameter list x, including:
1) the relative weight of the natal habitat in determining individual condition (Omega)
2) the strength of male competition (Beta)
3) the mating system (MS)
4) spatial autocorrelation of the environment
5) temporal autocorrelation of the environment
6) dispersal kernel

The main function then pass the parameter values to the function DispersalSimulation_HardHard.m, which simulates the population dynamics when both males and females are under hard selection.