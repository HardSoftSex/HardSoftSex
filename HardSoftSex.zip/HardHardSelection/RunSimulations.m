%Parameter list:
%PopSize, NumHabitats, pSpatial, pTemporal, k, InitDispersalProb, InitDispersalSigma, MutSigmaPhenotype, MutSigmaDispersal, DeathLambda, DispKernel, Beta, WeightNatalHab, MatingSystem, NumRepeats

Omega = 0;
Beta = 1;
MS = 1 ;%MatingSystem cases: 1-> Monogamy, 3-> Polygyny
ps=0.5;
pt=0.5;
Kernel =4; %DisperKernel cases: 4-> Geometric 5-> Poisson, 6-> Zipf

DispersalSummary=[];
for i=1:50
	x=[1000,30,ps,pt,10,0.25,0,0.01,0.01,0.1,Kernel,Beta,Omega,MS];
	x=mat2cell(x,1,ones(1,length(x)));
	x{length(x)+1}=i;
	SummaryData = DispersalSimulation_HardHard(x{:});
	DispersalSummary=[DispersalSummary; SummaryData];
end

csvwrite([strcat("HH-Monogamy-WeightNatal-", num2str(Omega), "-beta-", num2str(Beta), "-ps-", num2str(ps), "-pt-", num2str(pt)), ".csv"], DispersalSummary);
