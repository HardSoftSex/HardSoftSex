!ReadMe

There are three main simulation scenarios:
1) both sexes are under hard selection;
2) females are under hard selection while males under soft selection;
3) both sexes are under soft selection.

The simulation codes for each of the cases are provided. 
Further instructions on how to run the code please refer to the Read Me files under each directory.