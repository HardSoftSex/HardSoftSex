function [HabitatsAfterDispersal]=ZipfDisperse(numHabitats, CurrentHabitats, ProbOffspringDispersal,deathLambda)

popSize=length(CurrentHabitats);
HabitatsAfterDispersal=zeros(1,popSize);
zipfCDF=[0.434254,0.611843,0.717102,0.789727,0.844186,0.887232,0.922515,0.952215,0.977729,1];

for i=1:popSize
	currentHabitat=CurrentHabitats(i);
	willmove=rand<ProbOffspringDispersal(i);
	if willmove
		steps = find(zipfCDF>rand,1);

		deathRate = geocdf(steps-1,deathLambda);

		if rand<deathRate
			continue;
		end

		if rand<0.5
			currentHabitat=rem(currentHabitat + steps + 2*numHabitats, numHabitats);
		else
			currentHabitat=rem(currentHabitat - steps + 2*numHabitats, numHabitats);
		end

		if currentHabitat == 0
			currentHabitat = numHabitats;
		end
	end
	HabitatsAfterDispersal(i)=currentHabitat;
end

end