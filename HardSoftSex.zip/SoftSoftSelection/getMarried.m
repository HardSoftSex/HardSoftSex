function [matrixWives] = getMarried(femalesIdx, femalesFitness, malesIdx, malesFitness,Beta)
	matrixWives=[];
	while and(length(femalesIdx)>0, length(malesIdx)>0)
		chosenFemaleIdx = myID_parent(femalesFitness);
		wife_idx = femalesIdx(chosenFemaleIdx);
		wife_fitness = femalesFitness(chosenFemaleIdx);
		
		chosenMaleIdx = ChoseMale_Beta(malesFitness,Beta);
		husband_idx = malesIdx(chosenMaleIdx);
		matrixWives=[matrixWives,[wife_idx; wife_fitness; husband_idx]];
		
		femalesIdx(chosenFemaleIdx)=[];
		femalesFitness(chosenFemaleIdx)=[];
		malesIdx(chosenMaleIdx)=[];
		malesFitness(chosenMaleIdx)=[];
	end
end


