%%%%%%%%%%%%%%%%%%%%%  IMPORTANT!!! CHECK Genome Structure  %%%%%%%%%%%%%%%%%%%%%%
%phenotypeLocus = 1:2;
%df = 3:4;
%ds = 5:6;
%dm = 7:8;
%dispProb = 9;
%sex = 10;
%hab_Natal = 11;
%hab_Breeding = 12;
%adp_Natal = 13;
%adp_Breeding = 14;
%adp_Total = 15;


function [babyMatrix] = makeBabies(populationMatrix, MomIDs, DadIDs)
	popSize = length(MomIDs);
	babyMatrix = zeros(15,popSize);
	MomMatrix = populationMatrix(:,MomIDs);
	DadMatrix = populationMatrix(:,DadIDs);
	
	momAlleles = [];
	for i=1:4 %4 is the number of diploid loci
		momAlleles = [momAlleles; pickOneAlleleAtLocus(popSize)];
	end
	
	dadAlleles = 1 - momAlleles;
	babyMatrix(1:8,:) = MomMatrix(1:8,:) .* momAlleles + DadMatrix(1:8,:) .* dadAlleles;
	babyMatrix(10,:) = unidrnd(2,1,popSize)-1; %determine sex randomly
	babyMatrix(11,:) = MomMatrix(12,:); %offspring natal habitat is the mother's breeding habitat
end

function[myAllele] = pickOneAlleleAtLocus(popSize)
	myRow = unidrnd(2,1,popSize)-1;
	myAllele = [myRow; 1-myRow];
end

