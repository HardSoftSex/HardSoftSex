function [WivesMatrix] = makeHarem(femalesIdx, femalesFitness, malesIdx, malesFitness, beta)
	WivesMatrix = [];
	for i=1:length(femalesIdx)
		chosenMaleIdx = ChoseMale_Beta(malesFitness, beta);
		husbandIdx = malesIdx(chosenMaleIdx);
		WivesMatrix = [WivesMatrix,[femalesIdx(i); femalesFitness(i); husbandIdx]];
	end
end