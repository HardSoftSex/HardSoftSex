function [HabitatsAfterDispersal]=GeometricDisperse(numHabitats, CurrentHabitats, ProbOffspringDispersal,deathLambda)
	
popSize=length(CurrentHabitats);
HabitatsAfterDispersal=zeros(1,popSize);

for i=1:popSize
	currentHabitat=CurrentHabitats(i);
	willmove=rand<ProbOffspringDispersal(i);
	if willmove
		steps = geornd(0.35)+1;
		
		deathRate = geocdf(steps-1,deathLambda);
		
		if rand<deathRate
			continue;
		end
		
		if rand<0.5
			currentHabitat=rem(currentHabitat + steps + 2*numHabitats, numHabitats);
		else
			currentHabitat=rem(currentHabitat - steps + 2*numHabitats, numHabitats);
		end
		
		if currentHabitat == 0
			currentHabitat = numHabitats;
		end
	end
	HabitatsAfterDispersal(i)=currentHabitat;
end

end


%%%%%%%%%%%%%%% Test the Function %%%%%%%%%%%%%
%numHabitats = 10;
%CurrentHabitats = 1*ones(1,50);
%ProbOffspringDispersal = 0.5*ones(1,50);
%newHabitats = PoissonDisperse(numHabitats, CurrentHabitats, ProbOffspringDispersal)