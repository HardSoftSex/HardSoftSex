function [SummaryData]= DispersalSimulation_SoftSoft(InitpopSize, NumHabitats, pSpatial, pTemporal, k, InitDispersalProb, InitDispersalSigma, MutSigmaPhenotype, MutSigmaDispersal, DeathLambda, DispKernel, Beta, WeightNatalHab, MatingSystem, NumRepeats)
	%%%%%%%%%%% individuals %%%%%%%%%%%
	phenotypeLocus = 1:2;
	df = 3:4;
	ds = 5:6;
	dm = 7:8;
	dispProb = 9;
	sex = 10;
	hab_Natal = 11;
	hab_Breeding = 12;
	adp_Natal = 13;
	adp_Breeding = 14;
	adp_Total = 15;
	
	totalTraits = adp_Total;
	
	%%%%%%%%%%% Habitat initialisation %%%%%%%%%%%
	%To always start from the same environment
	randomStete=csvread("randStateFile.csv");
	rand("state",randomStete);
	inputEnvironment=rand(1,NumHabitats)<0.5; 	%In Luke and Hanna's paper: inputEnvironment=unidrnd(2,1,numGrid)-1;
	Env=UpdateEnvironment(inputEnvironment,NumHabitats,pSpatial,pTemporal,500);
	
	%%%%%%%%%%% Initialise Population %%%%%%%%%%%%%
	pop = zeros(totalTraits, InitpopSize);
	pop(phenotypeLocus,:) = rand(2,InitpopSize);
	pop(df(1):dm(end),:) = min(1,max(0,normrnd(InitDispersalProb,InitDispersalSigma,[6,InitpopSize]))); % 6 dispersal loci in total
	pop(sex,:) = rand(1,InitpopSize) < 0.5; % females: 0, males: 1.
	pop(hab_Natal,:) = unidrnd (NumHabitats, 1, InitpopSize);
	
	%%%%%%%%%%%% Output data %%%%%%%%%%%%
	SummaryData=[];
	
	t=0;
	
	while t<5000 % simulations should run 500-3000 steps in any case
		t = t+1
		%%%%%%%% adaptedness to the natal habitat %%%%%%%%%
		for i=1:NumHabitats
			idx_females=find(and(pop(hab_Natal,:)==i, pop(sex,:)==0));
			pop(adp_Natal,idx_females) = FitnessOrder1(mean(pop(phenotypeLocus,idx_females)),Env(i),k);
			idx_males = find(and(pop(hab_Natal,:)==i, pop(sex,:)==1));
			pop(adp_Natal,idx_males) = FitnessOrder1(mean(pop(phenotypeLocus,idx_males)),Env(i),k);
		end
		
		%%%%%%% dispersal and adaptedness to the breeding habitat %%%%%%%%
		% The index of breeding habitat is set to 0 if the individual dies because of dispersal
		% 3 different dispersal kernels
		pop(dispProb,:)=mean(pop(df(1):ds(end),:)).*(pop(sex,:)==0)+mean(pop(ds(1):dm(end),:)).*(pop(sex,:)==1);
		
		switch DispKernel
		case 4 % Geometric Kernel
			pop(hab_Breeding,:)= GeometricDisperse(NumHabitats, pop(hab_Natal,:), pop(dispProb,:), DeathLambda);
		case 5 % Poisson Kernel
			pop(hab_Breeding,:)= PoissonDisperse(NumHabitats, pop(hab_Natal,:), pop(dispProb,:), DeathLambda);
		case 6 % Zipf Kernel
			pop(hab_Breeding,:)= ZipfDisperse(NumHabitats, pop(hab_Natal,:), pop(dispProb,:), DeathLambda);
		end
		
		for i=1:NumHabitats
			idx_females=find(and(pop(hab_Breeding,:)==i, pop(sex,:)==0));
			pop(adp_Breeding,idx_females) = FitnessOrder1(mean(pop(phenotypeLocus,idx_females)),Env(i),k);
			idx_males = find(and(pop(hab_Breeding,:)==i, pop(sex,:)==1));
			pop(adp_Breeding,idx_males) = FitnessOrder1(mean(pop(phenotypeLocus,idx_males)),Env(i),k);
		end
		
		%%%%%% Total adaptedness %%%%%%%
		pop(adp_Total,:) = WeightNatalHab * pop(adp_Natal,:) + (1-WeightNatalHab) * pop(adp_Breeding,:);
		
		%%%%%% Population census %%%%%%%
		
		%1-> total number of individuals
		totalN = sum(pop(hab_Breeding,:) != 0);
		if totalN < 50
			break;
		end
		
		%2-> Habitats on which breeding is possible
		effectiveHabs = EffectiveHabitats(NumHabitats, pop(hab_Breeding,:), pop(sex,:));
		NumEffectiveHabs = length(effectiveHabs);
		if NumEffectiveHabs < 1
			break;
		end
		
		%3-> mean dispersal Probability of females and males
		allFemales = find(and(pop(sex,:)==0, pop(hab_Breeding,:)!=0));
		meanFemaleDisp = mean(pop(dispProb,allFemales));
		
		allMales = find(and(pop(sex,:)==1, pop(hab_Breeding,:)!=0));
		meanMaleDisp = mean(pop(dispProb,allMales));
		
		%4-> mean and variance of the conditions of philopatric and immigrant males
		PhilopatricMales = find(and(pop(sex,:)==1, pop(hab_Breeding,:) == pop(hab_Natal,:)));
		meanPhiloMaleAdp = mean(pop(adp_Total,PhilopatricMales));
		varPhiloMaleAdp = var(pop(adp_Total,PhilopatricMales));
		
		ImmigrantMales = find(and(pop(sex,:)==1, pop(hab_Breeding,:) != pop(hab_Natal,:)));
		meanImmiMaleAdp = mean(pop(adp_Total,ImmigrantMales));
		varImmiMaleAdp = var(pop(adp_Total,ImmigrantMales));
		
		PhilopatricFemales = find(and(pop(sex,:)==0, pop(hab_Breeding,:) == pop(hab_Natal,:)));
		meanPhiloFemaleAdp = mean(pop(adp_Total,PhilopatricFemales));
		varPhiloFemaleAdp = var(pop(adp_Total,PhilopatricFemales));

		ImmigrantFemales = find(and(pop(sex,:)==0, pop(hab_Breeding,:) != pop(hab_Natal,:)));
		meanImmiFemaleAdp = mean(pop(adp_Total,ImmigrantFemales));
		varImmiFemaleAdp = var(pop(adp_Total,ImmigrantFemales));
		
		%%%%%%%%% Breeding starts %%%%%%%%%%%%
		switch MatingSystem
		case 1   %if Monogamy
			MatrixMatches = [];
			% row 1 -> indices of Females
			% row 2 -> adaptedness of females
			% row 3 -> indices of males
		
			for i=effectiveHabs
				femaleIDs = find(and(pop(sex,:)==0,pop(hab_Breeding,:)==i)); 
				%normalize female fecundity
				pop(adp_Total,femaleIDs) = (InitpopSize / NumHabitats) * pop(adp_Total,femaleIDs) / sum(pop(adp_Total,femaleIDs));
				maleIDs = find(and(pop(sex,:)==1,pop(hab_Breeding,:)==i));
				newMatches=getMarried(femaleIDs, pop(adp_Total, femaleIDs), maleIDs, pop(adp_Total, maleIDs), Beta);
				MatrixMatches=[MatrixMatches, newMatches];			
			end
			
			ParentMatrix = storkPicks(popSize, MatrixMatches(1,:), MatrixMatches(2,:), MatrixMatches(3,:));
			
		% case 2 % Polygyandry
		%
		% 	PotentialParents=[];
		% 	% row 1 -> indices of females
		% 	% row 2 -> indices of males
		%
		% 	for i=effectiveHabs
		% 		femaleIDs = find(and(pop(sex,:)==0,pop(hab_Breeding,:)==i));
		% 		%normalize female fecundity
		% 		pop(adp_Total,femaleIDs) = (InitpopSize / NumHabitats) * pop(adp_Total,femaleIDs) / sum(pop(adp_Total,femaleIDs));
		% 		maleIDs = find(and(pop(sex,:)==1,pop(hab_Breeding,:)==i));
		% 		newParents=pairParents(femaleIDs, pop(adp_Total, femaleIDs), maleIDs, pop(adp_Total, maleIDs), Beta);
		% 		PotentialParents=[PotentialParents, newParents];
		% 	end
		%
		% 	storkPickedPairs = randperm(size(PotentialParents)(2),popSize);
		% 	ParentMatrix = PotentialParents(:,storkPickedPairs);
			
		case 3 % Polygyny
			MatrixMatches=[];
			% row 1 -> indices of females
			% row 2 -> adaptedness of females
			% row 3 -> indices of males
		
			for i=effectiveHabs
				femaleIDs = find(and(pop(sex,:)==0,pop(hab_Breeding,:)==i)); 
				%normalize female fecundity
				pop(adp_Total,femaleIDs) = (InitpopSize / NumHabitats) * pop(adp_Total,femaleIDs) / sum(pop(adp_Total,femaleIDs));
				maleIDs = find(and(pop(sex,:)==1,pop(hab_Breeding,:)==i));
				newMatches=makeHarem(femaleIDs, pop(adp_Total, femaleIDs), maleIDs, pop(adp_Total, maleIDs), Beta);
				MatrixMatches=[MatrixMatches, newMatches];			
			end
		
			ParentMatrix = storkPicks(InitpopSize, MatrixMatches(1,:), MatrixMatches(2,:), MatrixMatches(3,:));
		end
		

		%%%%%%%%% making babies %%%%%%%%%%
		popSize = size(ParentMatrix)(2);
		%number of offspring from philopatric females
		NumOffsFromPhilFems=sum(ismember(ParentMatrix(1,:),PhilopatricFemales));
		%number of offspring from immigrant females
		NumOffsFromImmiFems=sum(ismember(ParentMatrix(1,:),ImmigrantFemales));
		%number of offspring from philopatric males
		NumOffsFromPhilMales=sum(ismember(ParentMatrix(2,:),PhilopatricMales));
		%number of offspring from immigrant males
		NumOffsFromImmiMales=sum(ismember(ParentMatrix(2,:),ImmigrantMales));
		
		NumPhilMoms=sum(ismember(unique(ParentMatrix(1,:)),PhilopatricFemales));
		NumImmiMoms=sum(ismember(unique(ParentMatrix(1,:)),ImmigrantFemales));
		NumPhilDads=sum(ismember(unique(ParentMatrix(2,:)),PhilopatricMales));
		NumImmiDads=sum(ismember(unique(ParentMatrix(2,:)),ImmigrantMales));
		
		babyMatrix = makeBabies(pop, ParentMatrix(1,:), ParentMatrix(2,:));
		
		%offspring mutation
		mutations=[normrnd(0,MutSigmaPhenotype,2,popSize); normrnd(0,MutSigmaDispersal,6,popSize)];
		babyMatrix(1:8,:) = babyMatrix(1:8,:) + mutations;
		babyMatrix(3:8,:) = min(1,max(0,babyMatrix(3:8,:))); %dispersal probability is bounded within (0,1)
	
	    %%%%%%%%% updating population %%%%%%%%%%
		pop = babyMatrix;
		
		%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% updating environment %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		Env=UpdateEnvironment(Env,NumHabitats,pSpatial,pTemporal,1);
	end
	
	%%%% Record population snapshot
	SummaryData =[totalN, NumEffectiveHabs, meanPhiloMaleAdp, meanImmiMaleAdp, varPhiloMaleAdp, varImmiMaleAdp, meanFemaleDisp, meanMaleDisp, meanPhiloFemaleAdp, meanImmiFemaleAdp, varPhiloFemaleAdp, varImmiFemaleAdp, NumOffsFromPhilFems, NumOffsFromImmiFems, NumOffsFromPhilMales, NumOffsFromImmiMales, NumPhilMoms, NumImmiMoms, NumPhilDads, NumImmiDads];
	
	%csvwrite([strcat("SoftSoft-MS-", num2str(MatingSystem), "-WeightNatal-", num2str(WeightNatalHab), "-beta-",num2str(Beta),"-Rep-", num2str(NumRepeats), ".csv")], SummaryData);
	
end






























